"use strict";exports.id=6056,exports.ids=[6056],exports.modules={31180:(a,b,c)=>{c.d(b,{ZM:()=>g,to:()=>h});var d=c(97548),e=c(80409);async function f(a){let b,c=(0,e.LD)(),f=(0,e.kw)(),g=(0,e.dJ)();if(g||!c||!f)throw Error(`EMAIL_NOT_CONFIGURED: ${g??"email transport"} is not set`);let h={Authorization:`Bearer ${c}`,"Content-Type":"application/json"};a.idempotencyKey&&(h["Idempotency-Key"]=a.idempotencyKey);let i=new AbortController,j=setTimeout(()=>i.abort(),1e4);try{b=await fetch((0,e.PW)(),{method:"POST",headers:h,body:JSON.stringify({from:f,to:[a.to],subject:a.subject,html:a.html,...a.text?{text:a.text}:{}}),signal:i.signal})}catch(a){if(clearTimeout(j),a instanceof Error&&"AbortError"===a.name)throw Error("EMAIL_TIMEOUT: Resend API did not respond in time");throw Error(`EMAIL_NETWORK_ERROR: ${a instanceof Error?a.message:"unknown"}`)}clearTimeout(j);let k=await (0,d.o)(b);if(!b.ok)throw Error(`EMAIL_PROVIDER_ERROR: Resend ${b.status} ${k.message??""}`.trim());if(!k.id)throw Error("EMAIL_PROVIDER_ERROR: Resend response missing message id");return k.id}async function g(a){if(!(0,e.bE)()){let a=(0,e.dJ)()??"NK_RESEND_API_KEY";return console.error(`[Email] NOT CONFIGURED — set ${a} (mock success is no longer returned)`),{success:!1,error:`EMAIL_NOT_CONFIGURED: ${a} is not set`}}try{let b=await f(a);return{success:!0,messageId:b}}catch(a){if(a instanceof Error&&a.message.startsWith("EMAIL_NOT_CONFIGURED"))return console.error("[Email]",a.message),{success:!1,error:a.message};return{success:!1,error:a instanceof Error?a.message:"Unknown email error"}}}async function h(a,b=3){let c;for(let d=0;d<=b;d++){if(d>0){let a=1e3*Math.pow(2,d);await new Promise(b=>setTimeout(b,Math.min(a,5e3)))}let b=await g(a);if(b.success||b.error?.startsWith("EMAIL_NOT_CONFIGURED"))return b;c=b.error}return{success:!1,error:c??"Max retries exceeded"}}},46056:(a,b,c)=>{c.d(b,{B2:()=>f.B2,HR:()=>i});var d=c(35552),e=c(90701),f=c(84250),g=c(56472);async function h(a,b,c){let d=`${function(){let a="https://nongkatistore.com";if(a&&a.length>0)return a.replace(/\/+$/,"");throw Error("NEXT_PUBLIC_SITE_URL is required in production (customer-facing links would point at localhost)")}()}/orders/${b.confirmationUuid}`,e=b.items.map(a=>{let b=c.filter(b=>b.productName===a.productNameTh&&b.denomination===Number(a.denominationThb));return{productNameTh:a.productNameTh,denomination:Number(a.denominationThb),quantity:a.quantity,...b.length>0?{codes:b.map(a=>a.code)}:{}}}),h=(0,g.WU)({orderNumber:b.orderNumber,customerEmail:b.customerEmail,items:e,subtotalThb:Number(b.subtotalThb),vatAmountThb:Number(b.vatAmountThb),vatEnabled:!0===b.vatEnabled,vatRate:Number(b.vatRate??0),totalAmountThb:Number(b.totalAmountThb),confirmationUrl:d});await (0,f.RR)({idempotencyKey:`code_delivery:${b.id}`,templateKey:"code_delivery",to:b.customerEmail,subject:h.subject,html:h.html,tx:a})}async function i(a,b=d.z,c){let f=await b.order.findUnique({where:{id:a},include:{items:{include:{variant:{include:{product:!0}}}}}});if(!f)return{success:!1,error:"ORDER_NOT_FOUND"};if("completed"===f.status)return{success:!1,error:"ALREADY_FULFILLED"};try{let a=async a=>{let b=[];for(let c of f.items){let d=c.quantity;if(!c.variantId)throw Error("CATALOG_LINE_DETACHED");let g=await a.giftCode.findMany({where:{variantId:c.variantId,status:"available"},orderBy:{createdAt:"asc"},take:d,select:{id:!0,codeEncrypted:!0,nonce:!0,keyVersion:!0}});if(g.length<d)throw Error("INSUFFICIENT_STOCK");for(let d of g){let g=await a.giftCode.updateMany({where:{id:d.id,status:"available"},data:{status:"delivered",orderId:f.id,orderItemId:c.id,deliveredAt:new Date}});if(1!==g.count)throw Error("INSUFFICIENT_STOCK");b.push({code:(0,e.ZR)(d.codeEncrypted,d.nonce,d.keyVersion),productName:c.productNameTh,denomination:Number(c.denominationThb)})}let h=await a.productVariant.update({where:{id:c.variantId},data:{stock:{decrement:d}},select:{stock:!0}});h.stock<0&&await a.productVariant.updateMany({where:{id:c.variantId,stock:{lt:0}},data:{stock:0}}),await a.stockMove.create({data:{variantId:c.variantId,delta:-d,reason:"sale",refType:"order",refId:f.id,note:`ออเดอร์ ${f.orderNumber}`,stockAfter:Math.max(h.stock,0),actorType:"system"}}),await a.orderItem.update({where:{id:c.id},data:{deliveryStatus:"delivered",deliveredAt:new Date}})}return await a.order.update({where:{id:f.id},data:{status:"completed",completedAt:new Date}}),await h(a,f,b),b},c=b===d.z?await d.z.$transaction(b=>a(b)):await a(b);return{success:!0,codes:c}}catch(a){if("INSUFFICIENT_STOCK"===(a instanceof Error?a.message:"")){if(c?.strict)throw a;return{success:!1,error:"INSUFFICIENT_STOCK"}}throw a}}},56472:(a,b,c)=>{c.d(b,{WU:()=>e,tg:()=>f});var d=c(76846);function e(a){let b=a.items.map(a=>{let b=(a.codes??[]).map(a=>`
    <tr>
      <td colspan="3" style="padding: 8px 12px; background: #f8f8f8; font-family: monospace; font-size: 14px; letter-spacing: 0.1em;">
        โค้ด: ${a}
      </td>
    </tr>
  `).join("");return`
    <tr>
      <td style="padding: 12px; border-bottom: 1px solid #eee;">${a.productNameTh}</td>
      <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: center;">${a.quantity}</td>
      <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: right;">${(0,d.yw)(a.denomination*a.quantity)}</td>
    </tr>
    ${b}
  `}).join("");return{subject:`ยืนยันคำสั่งซื้อ ${a.orderNumber} — Nong-Kati`,html:`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"></head>
      <body style="font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #f0a020; text-align: center;">✅ ชำระเงินสำเร็จ!</h1>

        <p>คำสั่งซื้อ <strong>${a.orderNumber}</strong></p>

        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <thead>
            <tr style="background: #f5f5f5;">
              <th style="padding: 12px; text-align: left;">สินค้า</th>
              <th style="padding: 12px; text-align: center;">จำนวน</th>
              <th style="padding: 12px; text-align: right;">ราคา</th>
            </tr>
          </thead>
          <tbody>
            ${b}
          </tbody>
        </table>

        <div style="text-align: right; margin: 20px 0;">
          <p>ยอดรวม: ${(0,d.yw)(a.subtotalThb)}</p>
          ${a.vatEnabled?`<p>VAT ${(100*a.vatRate).toLocaleString("th-TH")}% (รวมในราคา): ${(0,d.yw)(a.vatAmountThb)}</p>`:""}
          <p style="font-size: 18px; font-weight: bold; color: #f0a020;">รวมทั้งสิ้น: ${(0,d.yw)(a.totalAmountThb)}</p>
        </div>

        <div style="text-align: center; margin: 30px 0;">
          <a href="${a.confirmationUrl}" style="display: inline-block; padding: 12px 24px; background: #f0a020; color: #000; text-decoration: none; border-radius: 6px; font-weight: bold;">
            ดูคำสั่งซื้อและโค้ด
          </a>
        </div>

        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">

        <p style="font-size: 12px; color: #888; text-align: center;">
          Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์
        </p>
      </body>
      </html>
    `}}function f(a){let b=a.amountThb>0,c=`${b?"+":"-"}${(0,d.yw)(Math.abs(a.amountThb))}`,e=a.note?.trim()?`<p style="font-size: 14px; color: #555;">หมายเหตุ: ${a.note.trim()}</p>`:"",f=[b?"เพิ่มเครดิตในกระเป๋าของคุณ":"หักเครดิตจากกระเป๋าของคุณ",`จำนวน: ${c}`,`เครดิตคงเหลือ: ${(0,d.yw)(a.balanceThb)}`,...a.note?.trim()?[`หมายเหตุ: ${a.note.trim()}`]:[],"","Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์"].join("\n");return{subject:`${b?"เพิ่ม":"หัก"}เครดิต ${c} — Nong-Kati`,text:f,html:`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"></head>
      <body style="font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #f0a020; text-align: center;">
          ${b?"✅ เพิ่มเครดิตในกระเป๋าของคุณ":"➖ หักเครดิตจากกระเป๋าของคุณ"}
        </h1>

        <div style="background: #f8f8f8; padding: 16px; border-radius: 8px;">
          <p style="margin: 6px 0; font-size: 18px; font-weight: bold;">${c}</p>
          <p style="margin: 6px 0;">เครดิตคงเหลือ: <strong>${(0,d.yw)(a.balanceThb)}</strong></p>
        </div>

        ${e}

        <p style="font-size: 13px; color: #888;">
          รายการนี้ถูกบันทึกในหน้าภระเป๋าของคุณแล้ว (ประวัติการเติมเงิน/การใช้จ่าย)
        </p>
        <p style="font-size: 12px; color: #888; text-align: center;">
          Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์
        </p>
      </body>
      </html>
    `}}},80409:(a,b,c)=>{c.d(b,{LD:()=>g,PW:()=>f,bE:()=>i,dJ:()=>j,kw:()=>h});let d="NK_RESEND_API_KEY",e="NK_RESEND_FROM_EMAIL";function f(){let a=process.env.NK_RESEND_API_URL;return a&&""!==a.trim()?a:"https://api.resend.com/emails"}function g(){let a=process.env[d];return a&&"re_mock_key"!==a?a:null}function h(){let a=process.env[e];return a&&""!==a.trim()?a:null}function i(){return null!==g()&&null!==h()}function j(){return null===g()?d:null===h()?e:null}},84250:(a,b,c)=>{c.d(b,{B2:()=>i,LP:()=>g,RR:()=>f});var d=c(35552),e=c(31180);async function f(a){let b=await a.tx.emailOutbox.findUnique({where:{idempotencyKey:a.idempotencyKey},select:{id:!0}});return b?{enqueued:!1,id:b.id}:{enqueued:!0,id:(await a.tx.emailOutbox.upsert({where:{idempotencyKey:a.idempotencyKey},create:{idempotencyKey:a.idempotencyKey,templateKey:a.templateKey,toEmail:a.to,subject:a.subject,html:a.html,...void 0!==a.text?{text:a.text}:{}},update:{},select:{id:!0}})).id}}async function g(a=20){let b=new Date,c=new Date(b.getTime()-3e5),f=[{status:"pending",availableAt:{lte:b}},{status:"sending",updatedAt:{lt:c}}],h=await d.z.emailOutbox.findMany({where:{OR:f},orderBy:{availableAt:"asc"},select:{id:!0},take:a}),i=[];for(let a of h)1===(await d.z.emailOutbox.updateMany({where:{id:a.id,OR:f},data:{status:"sending",updatedAt:b}})).count&&i.push(a);let j=0,k=0;for(let a of i){let b=await d.z.emailOutbox.findUnique({where:{id:a.id},select:{id:!0,toEmail:!0,subject:!0,html:!0,text:!0,attempts:!0,idempotencyKey:!0}});if(!b)continue;let c=await (0,e.to)({to:b.toEmail,subject:b.subject,html:b.html,...null!==b.text?{text:b.text}:{},idempotencyKey:b.idempotencyKey});if(c.success){await d.z.emailOutbox.update({where:{id:b.id},data:{status:"sent",sentAt:new Date,lastError:null,updatedAt:new Date}}),j++;continue}let f=b.attempts+1,g=f>=8,h=Math.min(6e4*2**(f-1),36e5);await d.z.emailOutbox.update({where:{id:b.id},data:{status:g?"failed":"pending",attempts:f,lastError:c.error??"UNKNOWN_ERROR",availableAt:new Date(Date.now()+(g?0:h)),updatedAt:new Date}}),k++,console.error(`[email-outbox] delivery ${g?"parked as FAILED":"retry scheduled"} id=${b.id} to=${b.toEmail} attempts=${f} error=${c.error??"?"}`),g&&function(a,b,c,e,f){try{d.z.auditLog.create({data:{actorType:"system",actorId:"email-outbox",actorEmail:"system@nong-kati.local",action:"email_outbox_dead_letter",tableName:"EmailOutbox",recordId:a,metadata:{idempotencyKey:b,toEmail:c,attempts:e,error:f}}}).catch(b=>{console.error(`[email-outbox] FAILED to record dead-letter for ${a}:`,b instanceof Error?b.message:b)})}catch(b){console.error(`[email-outbox] FAILED to record dead-letter for ${a}:`,b instanceof Error?b.message:b)}}(b.id,b.idempotencyKey,b.toEmail,f,c.error??"UNKNOWN_ERROR")}return{processed:i.length,sent:j,failed:k}}async function h(){try{let a=Function("m","return import(m)"),b=await a("next/server");return"function"==typeof b?.after?b.after:null}catch{return null}}async function i(){try{let a=await h(),b=g().catch(a=>{console.error("[email-outbox] drain failed:",a instanceof Error?a.message:a)});a?a(()=>b):await b}catch{}}},90701:(a,b,c)=>{c.d(b,{JV:()=>i,Q5:()=>l,ZR:()=>j,s5:()=>k});var d=c(55511);let e="aes-256-gcm",f="NK_GIFT_CODE_ENCRYPTION_KEY",g="NK_GIFT_CODE_ENCRYPTION_KEY_V2";function h(a){let b=process.env[f];if(!b)throw Error(`${f} environment variable is not set`);let c=process.env[g],d=2===a&&c||b,e=2===a&&c?g:f;if(!/^[0-9a-fA-F]{64}$/.test(d))throw Error(`${e} must be 64 hex chars (32 bytes) — got ${d.length} chars; refusing to derive a weak key`);return Buffer.from(d,"hex")}function i(a,b=function(){let a=process.env.NK_GIFT_CODE_ACTIVE_KEY_VERSION;if(!a)return 1;let b=Number(a);if(1!==b&&2!==b)throw Error(`NK_GIFT_CODE_ACTIVE_KEY_VERSION must be 1 or 2 — got "${a}"`);return b}()){let c=h(b),f=(0,d.randomBytes)(12),g=(0,d.createCipheriv)(e,c,f),j=Buffer.concat([g.update(a,"utf8"),g.final()]),k=g.getAuthTag();return{ciphertext:Buffer.concat([j,k]),nonce:f,authTag:k,keyVersion:b}}function j(a,b,c=1){if(1!==c&&2!==c)throw Error(`GiftCode keyVersion ${c} is not supported by this build (knows 1–2) — deploy newer code before reading these rows`);let f=h(c);if(a.length<16)throw Error("Ciphertext too short — missing auth tag");let g=a.subarray(a.length-16),i=a.subarray(0,a.length-16),k=(0,d.createDecipheriv)(e,f,b);return k.setAuthTag(g),Buffer.concat([k.update(i),k.final()]).toString("utf8")}function k(a){return(0,d.createHash)("sha256").update(a.trim().toUpperCase()).digest()}function l(a){let b=a.split("\n");if(b.length>1)return`[บัญชี ${b.length} บรรทัด \xb7 ${a.length} ตัวอักษร]`;if(a.length>64)return`[บัญชียาว ${a.length} ตัวอักษร]`;let c=a.split("-");return c.length<=1?"*".repeat(Math.max(0,a.length-4))+a.slice(-4):c.map((a,b)=>b===c.length-1?a:"*".repeat(a.length)).join("-")}},97548:(a,b,c)=>{c.d(b,{o:()=>d});async function d(a){try{return await a.json()}catch{return console.warn("[safeJson] unparseable response body",{status:a.status,url:a.url}),{}}}}};