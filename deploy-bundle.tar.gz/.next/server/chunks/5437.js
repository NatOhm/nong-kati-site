"use strict";exports.id=5437,exports.ids=[5437],exports.modules={35437:(a,b,c)=>{c.d(b,{generateReceiptPdf:()=>e,generateTaxInvoicePdf:()=>f});var d=c(76846);async function e(a){let b=function(a){let b=a.items.map(a=>`
      <tr>
        <td>${a.productNameTh}</td>
        <td>${a.skuCode}</td>
        <td style="text-align: center;">${a.quantity}</td>
        <td style="text-align: right;">${(0,d.yw)(a.lineTotalThb)}</td>
      </tr>
    `).join("");return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 800px; margin: 0 auto; padding: 40px; }
        h1 { color: #f0a020; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #f5f5f5; }
        .total { text-align: right; font-size: 18px; font-weight: bold; color: #f0a020; }
        .footer { margin-top: 40px; text-align: center; color: #888; font-size: 12px; }
      </style>
    </head>
    <body>
      <h1>ใบเสร็จรับเงิน</h1>
      <p><strong>เลขที่:</strong> ${a.invoiceNumber}</p>
      <p><strong>วันที่:</strong> ${new Date(a.createdAt).toLocaleDateString("th-TH")}</p>
      <p><strong>คำสั่งซื้อ:</strong> ${a.orderNumber}</p>
      <p><strong>อีเมล:</strong> ${a.customerEmail}</p>

      <table>
        <thead>
          <tr>
            <th>สินค้า</th>
            <th>SKU</th>
            <th>จำนวน</th>
            <th style="text-align: right;">ราคา</th>
          </tr>
        </thead>
        <tbody>
          ${b}
        </tbody>
      </table>

      <div class="total">
        <p>ยอดรวม: ${(0,d.yw)(a.subtotalThb)}</p>
        ${a.vatEnabled?`<p>VAT ${(100*a.vatRate).toLocaleString("th-TH")}%: ${(0,d.yw)(a.vatAmountThb)}</p>`:""}
        <p>รวมทั้งสิ้น: ${(0,d.yw)(a.totalAmountThb)}</p>
      </div>

      <div class="footer">
        <p>Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์</p>
      </div>
    </body>
    </html>
  `}(a);return{success:!0,buffer:Buffer.from(b,"utf8"),filename:`receipt-${a.invoiceNumber}.html`,contentType:"text/html; charset=utf-8"}}async function f(a){if("tax_invoice"!==a.invoiceType)return{success:!1,filename:"",contentType:""};let b=function(a){let b=a.items.map(a=>`
      <tr>
        <td>${a.productNameTh}</td>
        <td>${a.skuCode}</td>
        <td style="text-align: center;">${a.quantity}</td>
        <td style="text-align: right;">${(0,d.yw)(a.unitPriceExVat)}</td>
        <td style="text-align: right;">${(0,d.yw)(a.unitVatAmount)}</td>
        <td style="text-align: right;">${(0,d.yw)(a.lineTotalThb)}</td>
      </tr>
    `).join("");return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 800px; margin: 0 auto; padding: 40px; }
        h1 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #f5f5f5; }
        .total { text-align: right; font-size: 18px; font-weight: bold; }
        .seller-info { margin: 20px 0; padding: 15px; border: 1px solid #eee; }
      </style>
    </head>
    <body>
      <h1>ใบกำกับภาษี</h1>
      <p><strong>เลขที่:</strong> ${a.invoiceNumber}</p>
      <p><strong>วันที่:</strong> ${new Date(a.createdAt).toLocaleDateString("th-TH")}</p>

      <div class="seller-info">
        <h3>ผู้จำหน่าย</h3>
        <p>ชื่อ: ${a.sellerName??"Nong-Kati"}</p>
        <p>เลขประจำตัวผู้เสียภาษี: ${a.sellerTaxId??"0-0000-00000-00-0"}</p>
        <p>ที่อยู่: ${a.sellerAddress??"-"}</p>
      </div>

      <div class="seller-info">
        <h3>ผู้ซื้อ</h3>
        <p>ชื่อ: ${a.buyerName??"-"}</p>
        <p>เลขประจำตัวผู้เสียภาษี: ${a.buyerTaxId??"-"}</p>
      </div>

      <table>
        <thead>
          <tr>
            <th>สินค้า</th>
            <th>SKU</th>
            <th>จำนวน</th>
            <th style="text-align: right;">ราคา (ก่อน VAT)</th>
            <th style="text-align: right;">VAT</th>
            <th style="text-align: right;">รวม</th>
          </tr>
        </thead>
        <tbody>
          ${b}
        </tbody>
      </table>

      <div class="total">
        <p>ยอดรวม (ก่อน VAT): ${(0,d.yw)(a.subtotalThb)}</p>
        ${a.vatEnabled?`<p>VAT ${(100*a.vatRate).toLocaleString("th-TH")}%: ${(0,d.yw)(a.vatAmountThb)}</p>`:""}
        <p>รวมทั้งสิ้น: ${(0,d.yw)(a.totalAmountThb)}</p>
      </div>
    </body>
    </html>
  `}(a);return{success:!0,buffer:Buffer.from(b,"utf8"),filename:`tax-invoice-${a.invoiceNumber}.html`,contentType:"text/html; charset=utf-8"}}}};