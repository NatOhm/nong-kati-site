"use strict";exports.id=5045,exports.ids=[5045,7749],exports.modules={7749:(a,b,c)=>{c.d(b,{T1:()=>r,ay:()=>p,checkRateLimit:()=>o});var d=c(10641);let e=[{route:"/api/v1/products",maxRequests:300,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/categories",maxRequests:300,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/search",maxRequests:60,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/search/suggest",maxRequests:120,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/cart",maxRequests:60,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/orders/preview",maxRequests:60,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/orders/vat",maxRequests:60,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/orders",maxRequests:10,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/orders/lookup",maxRequests:10,windowMs:9e5,keyBy:"ip"},{route:"_order_lookup_email",maxRequests:10,windowMs:9e5,keyBy:"email"},{route:"/api/v1/auth/login",maxRequests:20,windowMs:9e5,keyBy:"ip"},{route:"/api/v1/auth/register",maxRequests:20,windowMs:9e5,keyBy:"ip"},{route:"/api/v1/auth/admin/login",maxRequests:30,windowMs:18e5,keyBy:"ip"},{route:"/api/v1/auth/admin/2fa",maxRequests:30,windowMs:18e5,keyBy:"ip"},{route:"_order_velocity_email",maxRequests:20,windowMs:864e5,keyBy:"email"},{route:"_order_velocity_ip",maxRequests:30,windowMs:864e5,keyBy:"ip"},{route:"/api/v1/payments",maxRequests:20,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/admin",maxRequests:300,windowMs:6e4,keyBy:"ip"},{route:"/api/v1/legal/data-requests",maxRequests:5,windowMs:864e5,keyBy:"email"}],f=new Map;"undefined"!=typeof setInterval&&setInterval(()=>{let a=Date.now();for(let[b,c]of f.entries())c.resetAt<=a&&f.delete(b)},3e5);let g=process.env.UPSTASH_REDIS_REST_URL,h=process.env.UPSTASH_REDIS_REST_TOKEN,i=!!(g&&h),j="true"===process.env.NK_RATE_LIMIT_STRICT,k=["/api/v1/auth/","/api/v1/orders","/api/v1/payments","/api/v1/admin","/api/v1/legal/data-requests","/api/v1/cart"];function l(a){return k.some(b=>a.startsWith(b))}async function m(a,b){if(!i)return null;let c=Math.floor(Date.now()/b),d=`ratelimit:${a}:${c}`;try{let a=await fetch(`${g}/pipeline`,{method:"POST",headers:{Authorization:`Bearer ${h}`,"Content-Type":"application/json"},body:JSON.stringify([["INCR",d],["PEXPIRE",d,String(b)]]),signal:AbortSignal.timeout(1500)});if(!a.ok)return null;let e=await a.json(),f=Number(e[0]?.result??0);if(!Number.isFinite(f)||f<=0)return null;return{count:f,resetAt:(c+1)*b}}catch{return null}}async function n(a,b){if(!i)return null;let c=Math.floor(Date.now()/b),d=`ratelimit:${a}:${c}`;try{let a=await fetch(`${g}/pipeline`,{method:"POST",headers:{Authorization:`Bearer ${h}`,"Content-Type":"application/json"},body:JSON.stringify([["GET",d]]),signal:AbortSignal.timeout(1500)});if(!a.ok)return null;let e=await a.json(),f=Number(e[0]?.result??0);if(!Number.isFinite(f)||f<0)return null;return{count:f,resetAt:(c+1)*b}}catch{return null}}async function o(a,b,c,d){let e=d?.increment!==!1,g=c??q(a);if(!g)return{allowed:!0,remaining:1/0,resetAt:0,degraded:!1};let h=`${g.route}:${b}`;if(i){let b=e?await m(h,g.windowMs):await n(h,g.windowMs);if(b)return{allowed:e?b.count<=g.maxRequests:b.count<g.maxRequests,remaining:Math.max(0,g.maxRequests-b.count),resetAt:b.resetAt,degraded:!1};if(j&&l(a))return{allowed:!1,remaining:0,resetAt:Date.now()+1e4,degraded:!0}}let k=Date.now(),o=f.get(h);if(!o||o.resetAt<=k){let a=k+g.windowMs;return e?(!function(){if(f.size<1e4)return;let a=Date.now();for(let[b,c]of f.entries())c.resetAt<=a&&f.delete(b);if(f.size<1e4)return;let b=[...f.entries()].sort((a,b)=>a[1].resetAt-b[1].resetAt);for(let a=0;a<b.length&&f.size>=1e4;a++){let c=b[a];c&&f.delete(c[0])}}(),f.set(h,{count:1,resetAt:a}),{allowed:!0,remaining:g.maxRequests-1,resetAt:a,degraded:i}):{allowed:!0,remaining:g.maxRequests,resetAt:a,degraded:i}}return o.count>=g.maxRequests?{allowed:!1,remaining:0,resetAt:o.resetAt,degraded:i}:(e&&o.count++,{allowed:!0,remaining:g.maxRequests-o.count,resetAt:o.resetAt,degraded:i})}async function p(a,b,c){let f=await o(a,b),g=e[0],h={"X-RateLimit-Limit":String((q(a)??g).maxRequests),"X-RateLimit-Remaining":String(f.remaining),"X-RateLimit-Reset":String(Math.ceil(f.resetAt/1e3)),"Retry-After":f.allowed?"0":String(Math.ceil((f.resetAt-Date.now())/1e3))};if(!f.allowed)return f.degraded&&j&&l(a)?d.NextResponse.json({success:!1,error:{code:"RATE_LIMITER_UNAVAILABLE",message:"ระบบป้องกันการใช้งานเกินขีดจำกัดขัดข้องชั่วคราว กรุณาลองใหม่ภายหลัง"}},{status:503,headers:{...h,"Retry-After":"10","Content-Type":"application/json"}}):d.NextResponse.json({success:!1,error:{code:"RATE_LIMIT_EXCEEDED",message:"คำขอเกินขีดจำกัด กรุณารอสักครู่แล้วลองใหม่อีกครั้ง"}},{status:429,headers:{...h,"Content-Type":"application/json"}});let i=c??d.NextResponse.next();for(let[a,b]of Object.entries(h))i.headers.set(a,b);return f.degraded&&i.headers.set("X-RateLimit-Degraded","memory-fallback"),i}function q(a){return e.find(b=>b.route===a)??e.find(b=>!b.route.startsWith("_")&&a.startsWith(b.route))}function r(a){let b=a.headers.get("x-forwarded-for");if(b){let a=b.split(",").map(a=>a.trim()).filter(Boolean),c=a[a.length-1];if(c)return c}return a.headers.get("x-real-ip")??"unknown"}},31180:(a,b,c)=>{c.d(b,{ZM:()=>g,to:()=>h});var d=c(97548),e=c(80409);async function f(a){let b,c=(0,e.LD)(),f=(0,e.kw)(),g=(0,e.dJ)();if(g||!c||!f)throw Error(`EMAIL_NOT_CONFIGURED: ${g??"email transport"} is not set`);let h={Authorization:`Bearer ${c}`,"Content-Type":"application/json"};a.idempotencyKey&&(h["Idempotency-Key"]=a.idempotencyKey);let i=new AbortController,j=setTimeout(()=>i.abort(),1e4);try{b=await fetch((0,e.PW)(),{method:"POST",headers:h,body:JSON.stringify({from:f,to:[a.to],subject:a.subject,html:a.html,...a.text?{text:a.text}:{}}),signal:i.signal})}catch(a){if(clearTimeout(j),a instanceof Error&&"AbortError"===a.name)throw Error("EMAIL_TIMEOUT: Resend API did not respond in time");throw Error(`EMAIL_NETWORK_ERROR: ${a instanceof Error?a.message:"unknown"}`)}clearTimeout(j);let k=await (0,d.o)(b);if(!b.ok)throw Error(`EMAIL_PROVIDER_ERROR: Resend ${b.status} ${k.message??""}`.trim());if(!k.id)throw Error("EMAIL_PROVIDER_ERROR: Resend response missing message id");return k.id}async function g(a){if(!(0,e.bE)()){let a=(0,e.dJ)()??"NK_RESEND_API_KEY";return console.error(`[Email] NOT CONFIGURED — set ${a} (mock success is no longer returned)`),{success:!1,error:`EMAIL_NOT_CONFIGURED: ${a} is not set`}}try{let b=await f(a);return{success:!0,messageId:b}}catch(a){if(a instanceof Error&&a.message.startsWith("EMAIL_NOT_CONFIGURED"))return console.error("[Email]",a.message),{success:!1,error:a.message};return{success:!1,error:a instanceof Error?a.message:"Unknown email error"}}}async function h(a,b=3){let c;for(let d=0;d<=b;d++){if(d>0){let a=1e3*Math.pow(2,d);await new Promise(b=>setTimeout(b,Math.min(a,5e3)))}let b=await g(a);if(b.success||b.error?.startsWith("EMAIL_NOT_CONFIGURED"))return b;c=b.error}return{success:!1,error:c??"Max retries exceeded"}}},45045:(a,b,c)=>{c.d(b,{T3:()=>g,m_:()=>h});var d=c(91038),e=c(31180),f=c(56472);async function g(a,b){let c=await (0,d.P7)(b);return c&&c.customerEmail.toLowerCase()===a.toLowerCase()?{success:!0,order:c}:{success:!1,error:"NOT_FOUND"}}async function h(a){let b=`https://nongkatistore.com/orders/${a.confirmationUuid}`,c=(0,f.WU)({orderNumber:a.orderNumber,customerEmail:a.customerEmail,items:a.items.map(a=>({productNameTh:a.productNameTh,denomination:Number(a.denominationThb),quantity:a.quantity})),subtotalThb:Number(a.subtotalThb),vatAmountThb:Number(a.vatAmountThb),vatEnabled:a.vatEnabled,vatRate:a.vatRate,totalAmountThb:Number(a.totalAmountThb),confirmationUrl:b}),d=await (0,e.to)({to:a.customerEmail,subject:c.subject,html:c.html});return d.success?{success:!0}:{success:!1,error:d.error}}c(7749)},56472:(a,b,c)=>{c.d(b,{WU:()=>e,tg:()=>f});var d=c(76846);function e(a){let b=a.items.map(a=>{let b=(a.codes??[]).map(a=>`
    <tr>
      <td colspan="3" style="padding: 8px 12px; background: #f8f8f8; font-family: monospace; font-size: 14px; letter-spacing: 0.1em;">
        โค้ด: ${a}
      </td>
    </tr>
  `).join("");return`
    <tr>
      <td style="padding: 12px; border-bottom: 1px solid #eee;">${a.productNameTh}</td>
      <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: center;">${a.quantity}</td>
      <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: right;">${(0,d.yw)(a.denomination*a.quantity)}</td>
    </tr>
    ${b}
  `}).join("");return{subject:`ยืนยันคำสั่งซื้อ ${a.orderNumber} — Nong-Kati`,html:`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"></head>
      <body style="font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #f0a020; text-align: center;">✅ ชำระเงินสำเร็จ!</h1>

        <p>คำสั่งซื้อ <strong>${a.orderNumber}</strong></p>

        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <thead>
            <tr style="background: #f5f5f5;">
              <th style="padding: 12px; text-align: left;">สินค้า</th>
              <th style="padding: 12px; text-align: center;">จำนวน</th>
              <th style="padding: 12px; text-align: right;">ราคา</th>
            </tr>
          </thead>
          <tbody>
            ${b}
          </tbody>
        </table>

        <div style="text-align: right; margin: 20px 0;">
          <p>ยอดรวม: ${(0,d.yw)(a.subtotalThb)}</p>
          ${a.vatEnabled?`<p>VAT ${(100*a.vatRate).toLocaleString("th-TH")}% (รวมในราคา): ${(0,d.yw)(a.vatAmountThb)}</p>`:""}
          <p style="font-size: 18px; font-weight: bold; color: #f0a020;">รวมทั้งสิ้น: ${(0,d.yw)(a.totalAmountThb)}</p>
        </div>

        <div style="text-align: center; margin: 30px 0;">
          <a href="${a.confirmationUrl}" style="display: inline-block; padding: 12px 24px; background: #f0a020; color: #000; text-decoration: none; border-radius: 6px; font-weight: bold;">
            ดูคำสั่งซื้อและโค้ด
          </a>
        </div>

        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">

        <p style="font-size: 12px; color: #888; text-align: center;">
          Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์
        </p>
      </body>
      </html>
    `}}function f(a){let b=a.amountThb>0,c=`${b?"+":"-"}${(0,d.yw)(Math.abs(a.amountThb))}`,e=a.note?.trim()?`<p style="font-size: 14px; color: #555;">หมายเหตุ: ${a.note.trim()}</p>`:"",f=[b?"เพิ่มเครดิตในกระเป๋าของคุณ":"หักเครดิตจากกระเป๋าของคุณ",`จำนวน: ${c}`,`เครดิตคงเหลือ: ${(0,d.yw)(a.balanceThb)}`,...a.note?.trim()?[`หมายเหตุ: ${a.note.trim()}`]:[],"","Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์"].join("\n");return{subject:`${b?"เพิ่ม":"หัก"}เครดิต ${c} — Nong-Kati`,text:f,html:`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"></head>
      <body style="font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #f0a020; text-align: center;">
          ${b?"✅ เพิ่มเครดิตในกระเป๋าของคุณ":"➖ หักเครดิตจากกระเป๋าของคุณ"}
        </h1>

        <div style="background: #f8f8f8; padding: 16px; border-radius: 8px;">
          <p style="margin: 6px 0; font-size: 18px; font-weight: bold;">${c}</p>
          <p style="margin: 6px 0;">เครดิตคงเหลือ: <strong>${(0,d.yw)(a.balanceThb)}</strong></p>
        </div>

        ${e}

        <p style="font-size: 13px; color: #888;">
          รายการนี้ถูกบันทึกในหน้าภระเป๋าของคุณแล้ว (ประวัติการเติมเงิน/การใช้จ่าย)
        </p>
        <p style="font-size: 12px; color: #888; text-align: center;">
          Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์
        </p>
      </body>
      </html>
    `}}},80409:(a,b,c)=>{c.d(b,{LD:()=>g,PW:()=>f,bE:()=>i,dJ:()=>j,kw:()=>h});let d="NK_RESEND_API_KEY",e="NK_RESEND_FROM_EMAIL";function f(){let a=process.env.NK_RESEND_API_URL;return a&&""!==a.trim()?a:"https://api.resend.com/emails"}function g(){let a=process.env[d];return a&&"re_mock_key"!==a?a:null}function h(){let a=process.env[e];return a&&""!==a.trim()?a:null}function i(){return null!==g()&&null!==h()}function j(){return null===g()?d:null===h()?e:null}},97548:(a,b,c)=>{c.d(b,{o:()=>d});async function d(a){try{return await a.json()}catch{return console.warn("[safeJson] unparseable response body",{status:a.status,url:a.url}),{}}}}};