"use strict";(()=>{var a={};a.id=859,a.ids=[859],a.modules={261:a=>{a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:a=>{a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29294:a=>{a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},31180:(a,b,c)=>{c.d(b,{ZM:()=>g,to:()=>h});var d=c(97548),e=c(80409);async function f(a){let b,c=(0,e.LD)(),f=(0,e.kw)(),g=(0,e.dJ)();if(g||!c||!f)throw Error(`EMAIL_NOT_CONFIGURED: ${g??"email transport"} is not set`);let h={Authorization:`Bearer ${c}`,"Content-Type":"application/json"};a.idempotencyKey&&(h["Idempotency-Key"]=a.idempotencyKey);let i=new AbortController,j=setTimeout(()=>i.abort(),1e4);try{b=await fetch((0,e.PW)(),{method:"POST",headers:h,body:JSON.stringify({from:f,to:[a.to],subject:a.subject,html:a.html,...a.text?{text:a.text}:{}}),signal:i.signal})}catch(a){if(clearTimeout(j),a instanceof Error&&"AbortError"===a.name)throw Error("EMAIL_TIMEOUT: Resend API did not respond in time");throw Error(`EMAIL_NETWORK_ERROR: ${a instanceof Error?a.message:"unknown"}`)}clearTimeout(j);let k=await (0,d.o)(b);if(!b.ok)throw Error(`EMAIL_PROVIDER_ERROR: Resend ${b.status} ${k.message??""}`.trim());if(!k.id)throw Error("EMAIL_PROVIDER_ERROR: Resend response missing message id");return k.id}async function g(a){if(!(0,e.bE)()){let a=(0,e.dJ)()??"NK_RESEND_API_KEY";return console.error(`[Email] NOT CONFIGURED — set ${a} (mock success is no longer returned)`),{success:!1,error:`EMAIL_NOT_CONFIGURED: ${a} is not set`}}try{let b=await f(a);return{success:!0,messageId:b}}catch(a){if(a instanceof Error&&a.message.startsWith("EMAIL_NOT_CONFIGURED"))return console.error("[Email]",a.message),{success:!1,error:a.message};return{success:!1,error:a instanceof Error?a.message:"Unknown email error"}}}async function h(a,b=3){let c;for(let d=0;d<=b;d++){if(d>0){let a=1e3*Math.pow(2,d);await new Promise(b=>setTimeout(b,Math.min(a,5e3)))}let b=await g(a);if(b.success||b.error?.startsWith("EMAIL_NOT_CONFIGURED"))return b;c=b.error}return{success:!1,error:c??"Max retries exceeded"}}},33873:a=>{a.exports=require("path")},44870:a=>{a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{a.exports=require("crypto")},56472:(a,b,c)=>{c.d(b,{WU:()=>e,tg:()=>f});var d=c(76846);function e(a){let b=a.items.map(a=>{let b=(a.codes??[]).map(a=>`
    <tr>
      <td colspan="3" style="padding: 8px 12px; background: #f8f8f8; font-family: monospace; font-size: 14px; letter-spacing: 0.1em;">
        โค้ด: ${a}
      </td>
    </tr>
  `).join("");return`
    <tr>
      <td style="padding: 12px; border-bottom: 1px solid #eee;">${a.productNameTh}</td>
      <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: center;">${a.quantity}</td>
      <td style="padding: 12px; border-bottom: 1px solid #eee; text-align: right;">${(0,d.yw)(a.denomination*a.quantity)}</td>
    </tr>
    ${b}
  `}).join("");return{subject:`ยืนยันคำสั่งซื้อ ${a.orderNumber} — Nong-Kati`,html:`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"></head>
      <body style="font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #f0a020; text-align: center;">✅ ชำระเงินสำเร็จ!</h1>

        <p>คำสั่งซื้อ <strong>${a.orderNumber}</strong></p>

        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <thead>
            <tr style="background: #f5f5f5;">
              <th style="padding: 12px; text-align: left;">สินค้า</th>
              <th style="padding: 12px; text-align: center;">จำนวน</th>
              <th style="padding: 12px; text-align: right;">ราคา</th>
            </tr>
          </thead>
          <tbody>
            ${b}
          </tbody>
        </table>

        <div style="text-align: right; margin: 20px 0;">
          <p>ยอดรวม: ${(0,d.yw)(a.subtotalThb)}</p>
          ${a.vatEnabled?`<p>VAT ${(100*a.vatRate).toLocaleString("th-TH")}% (รวมในราคา): ${(0,d.yw)(a.vatAmountThb)}</p>`:""}
          <p style="font-size: 18px; font-weight: bold; color: #f0a020;">รวมทั้งสิ้น: ${(0,d.yw)(a.totalAmountThb)}</p>
        </div>

        <div style="text-align: center; margin: 30px 0;">
          <a href="${a.confirmationUrl}" style="display: inline-block; padding: 12px 24px; background: #f0a020; color: #000; text-decoration: none; border-radius: 6px; font-weight: bold;">
            ดูคำสั่งซื้อและโค้ด
          </a>
        </div>

        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">

        <p style="font-size: 12px; color: #888; text-align: center;">
          Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์
        </p>
      </body>
      </html>
    `}}function f(a){let b=a.amountThb>0,c=`${b?"+":"-"}${(0,d.yw)(Math.abs(a.amountThb))}`,e=a.note?.trim()?`<p style="font-size: 14px; color: #555;">หมายเหตุ: ${a.note.trim()}</p>`:"",f=[b?"เพิ่มเครดิตในกระเป๋าของคุณ":"หักเครดิตจากกระเป๋าของคุณ",`จำนวน: ${c}`,`เครดิตคงเหลือ: ${(0,d.yw)(a.balanceThb)}`,...a.note?.trim()?[`หมายเหตุ: ${a.note.trim()}`]:[],"","Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์"].join("\n");return{subject:`${b?"เพิ่ม":"หัก"}เครดิต ${c} — Nong-Kati`,text:f,html:`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"></head>
      <body style="font-family: 'IBM Plex Sans Thai', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h1 style="color: #f0a020; text-align: center;">
          ${b?"✅ เพิ่มเครดิตในกระเป๋าของคุณ":"➖ หักเครดิตจากกระเป๋าของคุณ"}
        </h1>

        <div style="background: #f8f8f8; padding: 16px; border-radius: 8px;">
          <p style="margin: 6px 0; font-size: 18px; font-weight: bold;">${c}</p>
          <p style="margin: 6px 0;">เครดิตคงเหลือ: <strong>${(0,d.yw)(a.balanceThb)}</strong></p>
        </div>

        ${e}

        <p style="font-size: 13px; color: #888;">
          รายการนี้ถูกบันทึกในหน้าภระเป๋าของคุณแล้ว (ประวัติการเติมเงิน/การใช้จ่าย)
        </p>
        <p style="font-size: 12px; color: #888; text-align: center;">
          Nong-Kati — แอคดูหนัง ซีรีส์ ออนไลน์
        </p>
      </body>
      </html>
    `}}},63033:a=>{a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},80409:(a,b,c)=>{c.d(b,{LD:()=>g,PW:()=>f,bE:()=>i,dJ:()=>j,kw:()=>h});let d="NK_RESEND_API_KEY",e="NK_RESEND_FROM_EMAIL";function f(){let a=process.env.NK_RESEND_API_URL;return a&&""!==a.trim()?a:"https://api.resend.com/emails"}function g(){let a=process.env[d];return a&&"re_mock_key"!==a?a:null}function h(){let a=process.env[e];return a&&""!==a.trim()?a:null}function i(){return null!==g()&&null!==h()}function j(){return null===g()?d:null===h()?e:null}},80829:(a,b,c)=>{c.r(b),c.d(b,{handler:()=>L,patchFetch:()=>K,routeModule:()=>G,serverHooks:()=>J,workAsyncStorage:()=>H,workUnitAsyncStorage:()=>I});var d={};c.r(d),c.d(d,{GET:()=>E,PATCH:()=>F,dynamic:()=>C});var e=c(95736),f=c(9117),g=c(4044),h=c(39326),i=c(32324),j=c(261),k=c(54290),l=c(85328),m=c(38928),n=c(46595),o=c(3421),p=c(17679),q=c(41681),r=c(63446),s=c(86439),t=c(34679),u=c(51356),v=c(10641),w=c(38695),x=c(95846),y=c(49040),z=c(50973),A=c(31180),B=c(56472);let C="force-dynamic";function D(a){let b=(0,y.vg)(a);return b||null}async function E(a,b){let c=D(a);if(!c)return v.NextResponse.json({error:"UNAUTHENTICATED"},{status:401});let d=await (0,x.Yj)(c,"customers:read");if(!d.allowed)return v.NextResponse.json({error:d.error??"FORBIDDEN"},{status:403});let{id:e}=await b.params,f=await (0,w.CI)(e);if(!f)return v.NextResponse.json({error:"CUSTOMER_NOT_FOUND"},{status:404});let g=d.payload.perms.includes("customers:read:full");return v.NextResponse.json({...f,email:g?f.email:(0,x.vA)(f.email)})}async function F(a,b){let c,d=D(a);if(!d)return v.NextResponse.json({error:"UNAUTHENTICATED"},{status:401});let e=await (0,x.Yj)(d,"customers:write");if(!e.allowed)return v.NextResponse.json({error:e.error??"FORBIDDEN"},{status:403});try{c=await a.json()}catch{return v.NextResponse.json({error:"INVALID_JSON"},{status:400})}let f=c??{},{id:g}=await b.params;if("credit"===f.action){let a=await (0,w.s8)(g,f.amountThb,"string"==typeof f.note?f.note:void 0,e.payload?.sub??"unknown",e.payload?.email??"unknown");if(!a.success)return v.NextResponse.json({error:a.error},{status:"CUSTOMER_NOT_FOUND"===a.error?404:400});a.amountThb>0&&(0,z.W9)({customerEmail:a.customerEmail,amountThb:a.amountThb,balanceAfterThb:a.balanceThb});let b=!1;try{let c=(0,B.tg)({amountThb:a.amountThb,balanceThb:a.balanceThb,note:"string"==typeof f.note?f.note:void 0}),d=await (0,A.ZM)({to:a.customerEmail,subject:c.subject,html:c.html,text:c.text});b=d.success,d.success||console.error("[admin-credit] adjustment email not sent:",d.error)}catch(a){console.error("[admin-credit] adjustment email threw:",a instanceof Error?a.message:a)}return v.NextResponse.json({success:!0,balanceThb:a.balanceThb,amountThb:a.amountThb,emailed:b})}let h=await (0,w.kX)(g,f.tier,e.payload?.sub??"unknown",e.payload?.email??"unknown");return h.success?v.NextResponse.json({success:!0,tier:h.tier}):v.NextResponse.json({error:h.error??"TIER_CHANGE_FAILED"},{status:"CUSTOMER_NOT_FOUND"===h.error?404:400})}let G=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/v1/admin/customers/[id]/route",pathname:"/api/v1/admin/customers/[id]",filename:"route",bundlePath:"app/api/v1/admin/customers/[id]/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"E:\\งานนะจ๊ะ\\2569\\Nong-kati\\webapp\\nong-kati\\nong-kati\\src\\app\\api\\v1\\admin\\customers\\[id]\\route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:H,workUnitAsyncStorage:I,serverHooks:J}=G;function K(){return(0,g.patchFetch)({workAsyncStorage:H,workUnitAsyncStorage:I})}async function L(a,b,c){var d;let e="/api/v1/admin/customers/[id]/route";"/index"===e&&(e="/");let g=await G.prepare(a,b,{srcPage:e,multiZoneDraftMode:!1});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:v,params:w,nextConfig:x,isDraftMode:y,prerenderManifest:z,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!z.routes[D]&&(G.isDev||(0,t.isRouteCacheOwner)(D,G.cacheOwner,z.routes[D])),H=!!(z.dynamicRoutes[E]||F);if(H&&!y){let a=z.dynamicRoutes[E];if(a&&!1===a.fallback&&!F)throw new s.NoFallbackError}let I=null;!H||G.isDev||y||(I="/index"===(I=D)?"/":I);let J=!0===G.isDev||!H,K=H&&!J,L=a.method||"GET",M=(0,i.getTracer)(),N=M.getActiveScopeSpan(),O={params:w,prerenderManifest:z,renderOpts:{experimental:{cacheComponents:!!x.experimental.cacheComponents,authInterrupts:!!x.experimental.authInterrupts},supportsDynamicResponse:J,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=x.experimental)?void 0:d.cacheLife,isRevalidate:K,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>G.onRequestError(a,b,d,A)},sharedContext:{buildId:v}},P=new k.NodeNextRequest(a),Q=new k.NodeNextResponse(b),R=l.NextRequestAdapter.fromNodeNextRequest(P,(0,l.signalFromNodeResponse)(b));try{let d=async c=>G.handle(R,O).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=M.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${L} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${L} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=O.renderOpts.fetchMetrics;let i=O.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=O.renderOpts.collectedTags;if(!H)return await (0,o.I)(P,Q,e,O.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==O.renderOpts.collectedRevalidate&&!(O.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&O.renderOpts.collectedRevalidate,d=void 0===O.renderOpts.collectedExpire||O.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:O.renderOpts.collectedExpire;return{value:{kind:u.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await G.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:K,isOnDemandRevalidate:B})},A),b}},l=await G.handleResponse({req:a,nextConfig:x,cacheKey:I,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!H)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==u.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),y&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&H||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(P,Q,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};N?await g(N):await M.withPropagatedContext(a.headers,()=>M.trace(m.BaseServerSpan.handleRequest,{spanName:`${L} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":L,"http.target":a.url}},g))}catch(b){if(b instanceof s.NoFallbackError||await G.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:K,isOnDemandRevalidate:B})}),H)throw b;return await (0,o.I)(P,Q,new Response(null,{status:500})),null}}},86439:a=>{a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96330:a=>{a.exports=require("@prisma/client")},97548:(a,b,c)=>{c.d(b,{o:()=>d});async function d(a){try{return await a.json()}catch{return console.warn("[safeJson] unparseable response body",{status:a.status,url:a.url}),{}}}}};var b=require("../../../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[3897,1692,1001,973,3476],()=>b(b.s=80829));module.exports=c})();